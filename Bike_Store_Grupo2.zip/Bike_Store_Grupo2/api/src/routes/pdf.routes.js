const Router = require("express");
const { buildFechaPDF, buildVentaPDF } = require("../libs/pdfkits.js");

const router = Router();

router.post("/api/invoice", (req, res) => {
  const { tipo, data, filtro } = req.body;

  res.writeHead(200, {
    "Content-Type": "application/pdf",
    "Content-Disposition": `attachment; filename=reporte_${tipo}.pdf`,
  });

  // Seleccionar la función de generación según el tipo
  if (tipo === "fecha") {
    buildFechaPDF(
      (chunk) => res.write(chunk),
      () => res.end(),
      data,
      filtro
    );
  } else if (tipo === "venta") {
    buildVentaPDF(
      (chunk) => res.write(chunk),
      () => res.end(),
      data,
      filtro
    );
  } else {
    // si no es válido
    res.statusCode = 400;
    res.end("Tipo de reporte no soportado");
  }
});

module.exports = router;