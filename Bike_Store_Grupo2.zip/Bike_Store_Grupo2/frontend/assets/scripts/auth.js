// Verifica cuando la paguina esta lista (cargó el DOM)
document.addEventListener("DOMContentLoaded", async () => {
    // Obtiene el token guardado en el navegador del usuario
    const token = localStorage.getItem("token");
    // Elemento HTML donde se mostrará el nombre del usuario
    const userGreeting = document.getElementById("user-greeting");

    // Metodo para cerrar sesión: borra token y redirige
    const logout = () => {
        localStorage.removeItem("token");  // elimina el token del almacenamiento
        localStorage.removeItem("carrito");
        window.location.href = '/index.html';  // redirige a pagina principal
    };

    // Solo si existe un token guardado
    if (token) {
        try {
            // Hace petición al backend para verificar usuario
            const response = await fetch("http://localhost:3600/api/user", {
                headers: { Authorization: `Bearer ${token}` }  // envia token en cabecera
            });

            // Si la respuesta no es OK (ej: token invalido)
            if (!response.ok) {
                throw new Error(`Error HTTP: ${response.status}`);  // lanza error con codigo
            }

            // Convierte respuesta a JSON (datos del usuario)
            const userData = await response.json();
            
            // Si el rol es Cliente, actualiza la interfaz
            if (userData.rol === "Cliente") {
                // Inserta HTML con nombre y boton de logout
                userGreeting.innerHTML = `
                    <li class="usuario-info">
                        <a href="#" id="logout-btn" class="logout-btn">
                            <i class="fas fa-sign-out-alt"></i>${userData.nombre}, Cerrar Sesión
                        </a>
                    </li>
                `;

                // Agrega escuchador de clicks al boton de logout
                document.getElementById("logout-btn").addEventListener("click", (e) => {
                    e.preventDefault();  // evita que el link recargue la paguina
                    // Muestra confirmacion antes de cerrar sesión
                    if (confirm("¿Deseas cerrar sesión?")) {
                        logout();  // llama al metodo de logout
                    }
                });
            }
        } catch (error) {
            // Si hay error (ej: token expirado), muestra en consola y cierra sesión
            console.error("Error verificando sesión:", error);  // debug
            logout();  // limpia el token invalido
        }
    }
});