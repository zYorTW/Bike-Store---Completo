// Espera a que la paguina cargue completamente 
document.addEventListener('DOMContentLoaded', function() {
    cargarCarritoLocalStorage();
    actualizarCarritoDOM();     
    cargarProductosAccesorios();  // Llama a la funcion principal al iniciar
    // Listeners para el modal de compra
    document.querySelector(".cerrar-modal").addEventListener("click", cerrarModal);  // Boton cerrar
    document.getElementById("formulario-compra").addEventListener("submit", finalizarCompra);  // Envio de formulario
});

// Funcion asincrona para traer productos de accesorios desde el backend
async function cargarProductosAccesorios() {
    try {
        // Hace peticion al endpoint de accesorios
        const response = await fetch('http://localhost:3600/api/productos/accesorios');
        const productos = await response.json();  // Convierte respuesta a JSON
        const productGrid = document.querySelector('.product-grid');  // Contenedor de productos
        productGrid.innerHTML = '';  // Limpia contenido anterior (por si hay algo)

        // Itera cada producto y crea tarjetas
        productos.forEach(producto => {
            const stock = producto.entradas - producto.salidas;  // Calcula stock disponible
            // Genera HTML dinamico con los datos
            productGrid.innerHTML += `
                <div class="product-card">
                    <div class="product-image">
                        <img src="${producto.imagen_url}"  alt="${producto.nombre}">  <!-- Usa imagen placeholder si no hay URL -->
                    </div>
                    <div class="product-info">
                        <h3>${producto.nombre}</h3>
                        <p class="product-description">${producto.descripcion}</p>
                        <div class="product-meta">
                            <p class="product-price">$${producto.precio.toLocaleString()}</p>  <!-- Formatea precio con separadores -->
                            ${producto.destacado ? '<span class="destacado">¡Destacado!</span>' : ''}  <!-- Muestra etiqueta si esta destacado -->
                        </div>
                        <button class="add-to-cart" data-id="${producto.id}" ${stock <= 0 ? 'disabled' : ''}>
                            ${stock <= 0 ? 'Agotado' : 'Añadir al Carrito'}  <!-- Boton dinamico segun stock -->
                        </button>
                </div>
            `;
        });
        actualizarBotonesCarrito();
    } catch (error) {
        console.error('Error cargando bicicletas:', error);  // oops, dice bicicletas pero es para accesorios (debug)
        productGrid.innerHTML = '<p class="error">Error al cargar los accesorios</p>';  // Mensaje amigable para el usuario
    }
}

function toggleMenu() {
  const navContainer = document.querySelector(".nav-container"); // Contenedor del menú
  const hamburger = document.querySelector(".hamburger"); // Icono de hamburguesa

  navContainer.classList.toggle("active"); // Agrega/remueve clase active al menú
  hamburger.classList.toggle("active"); // Anima el icono hamburguesa a X
}

// Configura el comportamiento del menú en dispositivos mobiles 📱
function configurarMenuMobile() {
  const isMobile = window.innerWidth <= 768; // Detecta si es móvil por el ancho

  if (isMobile) {
    const dropdowns = document.querySelectorAll(".dropdown"); // Todos los submenus

    dropdowns.forEach((dropdown) => {
      const link = dropdown.querySelector("a"); // Enlace principal del dropdown

      // Evento click para móviles
      link.addEventListener("click", function(e) {
        e.preventDefault(); // Evita la navegación del enlace
        dropdown.classList.toggle("active"); // Abre/cierra el submenú

        // Cierra otros submenus abiertos
        dropdowns.forEach((otherDropdown) => {
          if (otherDropdown !== dropdown && otherDropdown.classList.contains("active")) {
            otherDropdown.classList.remove("active"); // Remueve clase active de otros
          }
        });
      });
    });
  }
}