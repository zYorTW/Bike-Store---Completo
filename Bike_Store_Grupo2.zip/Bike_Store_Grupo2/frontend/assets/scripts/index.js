// =============================================
// FUNCIONES DE PRODUCTOS
// =============================================

// Funcion para cargar productos destacados desde el backend
async function cargarProductosDestacados() {
  try {
    // Hacer peticion al endpoint de productos destacados
    const response = await fetch("http://localhost:3600/api/productos/destacados");

    if (!response.ok) {  // Si la respuesta falla (404, 500, etc)
      throw new Error("Error al cargar los productos destacados");  // Mensaje generico
    }

    const productos = await response.json();  // Parsea la respuesta a JSON
    const contenedor = document.getElementById("productos-destacados");
    contenedor.innerHTML = "";  // Limpia el contenedor de productos anteriores

    // Contruye cada tarjeta de producto
    productos.forEach((producto) => {
      const stock = producto.entradas - producto.salidas;  // Calcula stock disponible

      // Template string con HTML dinamico
      const tarjetaHTML = `
        <div class="product-card">
          <div class="product-image">
            <img src="${producto.imagen_url}" alt="${producto.nombre}" onerror="this.src='img/no-image.png'">   <!-- Si falla imagen, usa placeholder -->
          </div>
          <div class="product-info">
            <h3>${producto.nombre}</h3>  <!-- Nombre del producto -->
            <p class="product-price">$${parseFloat(producto.precio).toFixed(2)}</p>  <!-- Precio con 2 decimales -->
            <p class="product-stock">${stock > 0 ? `Disponible: ${stock}` : 'AGOTADO'}</p>  <!-- Muestra stock o agotado -->
            <p class="product-description">${producto.descripcion || ""}</p>  <!-- Descripcion opcional -->
            <p class="product-brand">Marca: ${producto.marca || "No especificada"}</p>  <!-- Marca con valor por defecto -->
            <button class="add-to-cart" data-id="${producto.id}" ${stock <= 0 ? 'disabled' : ''}>
              ${stock <= 0 ? 'Agotado' : 'Añadir al Carrito'}  <!-- Boton dinamico segun stock -->
            </button>
          </div>
        </div>
      `;

      contenedor.innerHTML += tarjetaHTML;  // Agrega la tarjeta al DOM
    });

    actualizarBotonesCarrito();  // Configura los eventos de los botones

  } catch (error) {
    console.error("Error al cargar productos:", error);  // Log para debug
    const contenedor = document.getElementById("productos-destacados");
    contenedor.innerHTML = "<p>No se pudieron cargar los productos destacados</p>";  // Mensaje de error simple
  }
}

// =============================================
// FUNCIONES DEL MENÚ
// =============================================

// Funcion para alternar la visibilidad del menú móvil 🍔
function toggleMenu() {
  const navContainer = document.querySelector(".nav-container"); // Contenedor del menú
  const hamburger = document.querySelector(".hamburger"); // Icono de hamburguesa

  navContainer.classList.toggle("active"); // Agrega/remueve clase active al menú
  hamburger.classList.toggle("active"); // Anima el icono hamburguesa a X
}

// Configura el comportamiento del menú en dispositivos mobiles 📱
function configurarMenuMobile() {
  const isMobile = window.innerWidth <= 768; // Detecta si es móvil por el ancho

  if (isMobile) {
    const dropdowns = document.querySelectorAll(".dropdown"); // Todos los submenus

    dropdowns.forEach((dropdown) => {
      const link = dropdown.querySelector("a"); // Enlace principal del dropdown

      // Evento click para móviles
      link.addEventListener("click", function(e) {
        e.preventDefault(); // Evita la navegación del enlace
        dropdown.classList.toggle("active"); // Abre/cierra el submenú

        // Cierra otros submenus abiertos
        dropdowns.forEach((otherDropdown) => {
          if (otherDropdown !== dropdown && otherDropdown.classList.contains("active")) {
            otherDropdown.classList.remove("active"); // Remueve clase active de otros
          }
        });
      });
    });
  }
}

// =============================================
// FUNCIONES DE ANIMACIONES
// =============================================

// Funcion para verificar scroll y activar animaciones al hacer scroll 📜
function checkScroll() {
  // Seleciona todos los elementos que tendran animaciones
  const elements = document.querySelectorAll(".product-card, .section-title, .about-content");

  // Recorre cada elemento animable
  elements.forEach((element) => {
    // Obtiene la posicion del elemento en el viewport
    const position = element.getBoundingClientRect();

    // Verifica si el elemento esta dentro del area visible
    if (position.top < window.innerHeight && position.bottom >= 0) {
      element.classList.add("animate");  // Agrega clase para trigger de animacion
    }
  });
}

// =============================================
// INICIALIZACIÓN
// =============================================

// Inicializacion al cargar la pagina
document.addEventListener("DOMContentLoaded", () => {
  cargarCarritoLocalStorage();
  cargarProductosDestacados();       // Carga productos destacados del backend
  actualizarCarritoDOM();            // Renderisa carrito inicial
  configurarMenuMobile();            // Aplica logica de menu para moviles
  checkScroll();                     // Chekea scroll al cargar para animaciones
  
  // Evento para animar elementos al hacer scroll
  window.addEventListener("scroll", checkScroll);
  
  // Listaners para el modal de compra
  document.querySelector(".cerrar-modal").addEventListener("click", cerrarModal);  // Boton cerrar
  document.getElementById("formulario-compra").addEventListener("submit", finalizarCompra);  // Envio de formulario
});