document.querySelector(".login-form").addEventListener("submit", async (event) => {
    event.preventDefault();

    const correo = document.getElementById("user_login").value.trim();
    const contraseña = document.getElementById("user_password").value.trim();

    try {
        const respuesta = await fetch("http://localhost:3600/api/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ correo, contraseña }),
        });

        // Verificar primero si hay error de red
        if (!respuesta.ok) {
            const errorData = await respuesta.json();
            throw new Error(errorData.message || `Error HTTP: ${respuesta.status}`);
        }

        const data = await respuesta.json();

        // Administrador
        if (respuesta.status === 201) {
            alert(data.message);
            window.location.href = "../pages/index-admin.html";
            return;
        }

        // Cliente
        if (respuesta.status === 200) {
            localStorage.setItem("token", data.token);

            try {
                const userResponse = await fetch("http://localhost:3600/api/user", {
                    headers: { Authorization: `Bearer ${data.token}` }
                });

                if (!userResponse.ok) {
                    throw new Error("Error al obtener datos del usuario");
                }

                const userData = await userResponse.json();
                alert(`¡Bienvenido ${userData.nombre}!`);
                window.location.href = "../../index.html";
            } catch (userError) {
                console.error("Error obteniendo datos usuario:", userError);
                throw new Error("Error al cargar información del usuario");
            }
            return;
        }

        throw new Error("Respuesta inesperada del servidor");

    } catch (error) {
        console.error("Error en login:", error);
        alert(`Error al iniciar sesión: ${error.message}`);
    }
});


function togglePassword() {
    //Función se activa desde el HTML
    const passwordInput = document.getElementById("user_password");
    const icon = document.querySelector(".toggle-password");

    //Cambia el tipo entre text y password
    if (passwordInput.type === "password") {
        // Cuando el input sea de tipo Password
        // Cambiará el tipo del input a texto:
        passwordInput.type = "text";
        // Cambiará el estado del Icono:
        icon.classList.remove("fa-eye"); //Borrará el estilo predeterminado
        icon.classList.add("fa-eye-slash"); //Colocará el otro estilo
    } else {
        //De lo contrario cambiará el tipo del input a password:
        passwordInput.type = "password";
        //Cambia el icono entre cerrar y abrir el ojo
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
    }
}

function toggleMenu() {
  const navContainer = document.querySelector(".nav-container"); // Contenedor del menú
  const hamburger = document.querySelector(".hamburger"); // Icono de hamburguesa

  navContainer.classList.toggle("active"); // Agrega/remueve clase active al menú
  hamburger.classList.toggle("active"); // Anima el icono hamburguesa a X
}

// Configura el comportamiento del menú en dispositivos mobiles 📱
function configurarMenuMobile() {
  const isMobile = window.innerWidth <= 768; // Detecta si es móvil por el ancho

  if (isMobile) {
    const dropdowns = document.querySelectorAll(".dropdown"); // Todos los submenus

    dropdowns.forEach((dropdown) => {
      const link = dropdown.querySelector("a"); // Enlace principal del dropdown

      // Evento click para móviles
      link.addEventListener("click", function(e) {
        e.preventDefault(); // Evita la navegación del enlace
        dropdown.classList.toggle("active"); // Abre/cierra el submenú

        // Cierra otros submenus abiertos
        dropdowns.forEach((otherDropdown) => {
          if (otherDropdown !== dropdown && otherDropdown.classList.contains("active")) {
            otherDropdown.classList.remove("active"); // Remueve clase active de otros
          }
        });
      });
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
    cargarCarritoLocalStorage();
    actualizarCarritoDOM();   // Renderisa carrito inicial    
    // Listeners para el modal de compra
    document.querySelector(".cerrar-modal").addEventListener("click", cerrarModal);  // Boton cerrar
    document.getElementById("formulario-compra").addEventListener("submit", finalizarCompra);  // Envio de formulario       
});

