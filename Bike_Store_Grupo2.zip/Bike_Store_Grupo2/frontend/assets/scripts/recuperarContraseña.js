document.getElementById('recoveryForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;

    try {
        // Verificar si el email existe
        const response = await fetch('http://localhost:3600/api/check-email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        });

        const data = await response.json();

        if (response.ok) {
            // Redirigir a la página de nueva contraseña
            window.location.href = `resetearContraseña.html?email=${encodeURIComponent(email)}`;
        } else {
            alert(data.error || 'El correo no está registrado');
        }
    } catch (error) {
        alert('Error al conectar con el servidor');
    }
});

document.addEventListener("DOMContentLoaded", () => {
    cargarCarritoLocalStorage();
    actualizarCarritoDOM();            // Renderisa carrito inicial    
    // Listeners para el modal de compra
    document.querySelector(".cerrar-modal").addEventListener("click", cerrarModal);  // Boton cerrar
    document.getElementById("formulario-compra").addEventListener("submit", finalizarCompra);  // Envio de formulario       
});

function toggleMenu() {
  const navContainer = document.querySelector(".nav-container"); // Contenedor del menú
  const hamburger = document.querySelector(".hamburger"); // Icono de hamburguesa

  navContainer.classList.toggle("active"); // Agrega/remueve clase active al menú
  hamburger.classList.toggle("active"); // Anima el icono hamburguesa a X
}

// Configura el comportamiento del menú en dispositivos mobiles 📱
function configurarMenuMobile() {
  const isMobile = window.innerWidth <= 768; // Detecta si es móvil por el ancho

  if (isMobile) {
    const dropdowns = document.querySelectorAll(".dropdown"); // Todos los submenus

    dropdowns.forEach((dropdown) => {
      const link = dropdown.querySelector("a"); // Enlace principal del dropdown

      // Evento click para móviles
      link.addEventListener("click", function(e) {
        e.preventDefault(); // Evita la navegación del enlace
        dropdown.classList.toggle("active"); // Abre/cierra el submenú

        // Cierra otros submenus abiertos
        dropdowns.forEach((otherDropdown) => {
          if (otherDropdown !== dropdown && otherDropdown.classList.contains("active")) {
            otherDropdown.classList.remove("active"); // Remueve clase active de otros
          }
        });
      });
    });
  }
}